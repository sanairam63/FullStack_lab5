// =============================================================================
// Task 2 - Academic Performance Intelligence Engine
// Main analytics use array methods: map, filter, find, findIndex, reduce,
// some, every, sort, slice, forEach.
//
// MUTATING array methods (change the array in place!):
//   sort, reverse, splice, push, pop, shift, unshift, fill, copyWithin
// NON-mutating: map, filter, slice, concat, find, reduce, some, every, spread
// => we copy with [...array] BEFORE calling sort().
// =============================================================================

const results = [
  { id: 1, name: 'Ali', department: 'CS', course: 'FSWD', marks: 82 },
  { id: 2, name: 'Sara', department: 'CS', course: 'FSWD', marks: 91 },
  { id: 3, name: 'Usman', department: 'SE', course: 'FSWD', marks: 47 },
  { id: 4, name: 'Hina', department: 'AI', course: 'FSWD', marks: 73 },
  { id: 5, name: 'Ahmed', department: 'SE', course: 'FSWD', marks: 64 },
  { id: 6, name: 'Zoya', department: 'AI', course: 'FSWD', marks: 91 },
];

const PASS_MARKS = 50;

// Grading policy, highest band first. find() returns the first band matched.
const GRADE_SCALE = [
  { min: 85, grade: 'A', gradePoints: 4.0 },
  { min: 80, grade: 'A-', gradePoints: 3.67 },
  { min: 75, grade: 'B+', gradePoints: 3.33 },
  { min: 70, grade: 'B', gradePoints: 3.0 },
  { min: 65, grade: 'B-', gradePoints: 2.67 },
  { min: 60, grade: 'C+', gradePoints: 2.33 },
  { min: 50, grade: 'C', gradePoints: 2.0 },
  { min: 0, grade: 'F', gradePoints: 0.0 },
];

const isValidMarks = (marks) => typeof marks === 'number' && Number.isFinite(marks) && marks >= 0 && marks <= 100;
const round2 = (value) => Math.round(value * 100) / 100;

// ---------- A. Result processing ----------------------------------------------
function gradeFor(marks) {
  if (!isValidMarks(marks)) throw new RangeError(`Invalid marks: ${marks}`);
  const { grade, gradePoints } = GRADE_SCALE.find((band) => marks >= band.min);
  return { grade, gradePoints, status: marks >= PASS_MARKS ? 'PASS' : 'FAIL' };
}

// map() returns NEW objects; the originals are not touched.
function processResults(list) {
  return list.map((student) => ({ ...student, ...gradeFor(student.marks) }));
}

// ---------- B. Ranked merit list ------------------------------------------------
// Marks descending; ties broken by name A-Z. [...list] copies first because
// sort() mutates. A rank is added with map().
function rankedMeritList(list) {
  return [...list]
    .sort((a, b) => b.marks - a.marks || a.name.localeCompare(b.name))
    .map((student, index) => ({ rank: index + 1, ...student }));
}

// ---------- C. Department statistics ---------------------------------------------
// Works for ANY department (including a new one such as "DS") because keys are
// created dynamically from the data - nothing is hard-coded.
function departmentStatistics(list) {
  const totals = list.reduce((accumulator, student) => {
    const current = accumulator[student.department] ?? { students: 0, total: 0, highest: -Infinity, passed: 0 };
    return {
      ...accumulator,
      [student.department]: {
        students: current.students + 1,
        total: current.total + student.marks,
        highest: Math.max(current.highest, student.marks),
        passed: current.passed + (student.marks >= PASS_MARKS ? 1 : 0),
      },
    };
  }, {});

  return Object.fromEntries(
    Object.entries(totals).map(([department, { students, total, highest, passed }]) => [
      department,
      { students, average: round2(total / students), highest, passed },
    ]),
  );
}

// ---------- D. Academic queries ----------------------------------------------------
function academicQueries(list) {
  const processed = processResults(list);
  const ranked = rankedMeritList(processed);
  const average = list.reduce((sum, s) => sum + s.marks, 0) / list.length;

  return {
    firstAbove85: list.find((s) => s.marks > 85) ?? null,
    indexOfFirstFailed: processed.findIndex((s) => s.status === 'FAIL'), // -1 if nobody failed
    anyoneFailed: processed.some((s) => s.status === 'FAIL'),
    allMarksValid: list.every((s) => isValidMarks(s.marks)),
    overallAverage: round2(average),
    aboveAverage: list.filter((s) => s.marks > average).map((s) => s.name),
    topThree: ranked.slice(0, 3).map((s) => s.name),
  };
}

// =============================================================================
// DEMO
// =============================================================================
const originalSnapshot = JSON.stringify(results);

console.log('=== A. Processed results ===');
const processed = processResults(results);
console.table(processed);

console.log('\n=== B. Ranked merit list (ties -> name A-Z) ===');
console.table(rankedMeritList(processed));
console.log('Original array order unchanged?', JSON.stringify(results) === originalSnapshot);

console.log('\n=== C. Department statistics ===');
console.log(departmentStatistics(results));

// A brand-new department appears later - no code change required:
const withNewDepartment = [...results, { id: 7, name: 'Bilal', department: 'DS', course: 'FSWD', marks: 58 }];
console.log('\nWith new department "DS":');
console.log(departmentStatistics(withNewDepartment));

console.log('\n=== D. Academic queries ===');
const queries = academicQueries(results);
queries.aboveAverage.forEach((name) => console.log('Above average:', name)); // forEach: side effects only
console.log(queries);

// ---- Edge cases ------------------------------------------------------------
console.log('\n=== Edge cases ===');
console.log('Empty department stats:', departmentStatistics([]));
const dirty = [...results, { id: 8, name: 'Bad', department: 'CS', course: 'FSWD', marks: 150 }];
console.log('every() on dirty data (marks 150):', dirty.every((s) => isValidMarks(s.marks)));
try {
  processResults(dirty);
} catch (error) {
  console.log(`processResults(dirty) -> ${error.name}: ${error.message}`);
}
console.log('Everybody passes -> index of first failed:', processResults(results.filter((s) => s.marks >= 50)).findIndex((s) => s.status === 'FAIL'));

console.log('\n=== Mutation demo ===');
const demo = [3, 1, 2];
const sortedCopy = [...demo].sort();
console.log('copy sorted:', sortedCopy, '| original still:', demo);
demo.sort();
console.log('sort() directly on original MUTATES it:', demo);
console.log('Original results still unchanged?', JSON.stringify(results) === originalSnapshot);
