// =============================================================================
// Task 1 - Admission Decision and Data Sanitization Engine
// Concepts: primitives, explicit type conversion, truthy/falsy, operators,
//           if/else, switch, ternary, loops, functions, guard clauses, scope.
// No closures are used (no function returns another function).
// =============================================================================
import { inspect } from 'node:util';

// ---- Configuration (const: these never change) -----------------------------
const AGE_MIN = 17;
const AGE_MAX = 30;
const MARKS_MIN = 0;
const MARKS_MAX = 100;
const MARK_FIELDS = ['matricMarks', 'intermediateMarks', 'entryTest'];
const WEIGHTS = { matricMarks: 20, intermediateMarks: 30, entryTest: 50 }; // percent
const MIN_MERIT = 70;
const MIN_ENTRY_TEST = 60;
const MIN_INTERMEDIATE = 60;

// SELECTED vs WAITING (our own, documented rule):
//   An ELIGIBLE applicant is SELECTED only if merit >= 75 AND the fee is paid.
//   An eligible applicant with merit in [70, 75) OR an unpaid fee is WAITING
//   (a seat can be offered later / once the fee is paid).
const SELECTION_MERIT = 75;

const STATUS = {
  SELECTED: 'SELECTED',
  WAITING: 'WAITING',
  REJECTED: 'REJECTED',
  INVALID: 'INVALID DATA',
};

// Only digits with an optional minus sign and decimal part. This blocks values
// such as '0x10', '1e2' or 'Infinity' that Number() would silently accept.
const NUMERIC_PATTERN = /^-?\d+(\.\d+)?$/;

// ---- Helper: explicit numeric conversion ------------------------------------
// Returns { value, error } instead of throwing, so the caller can collect ALL
// problems of an applicant in one pass.
function convertToNumber(rawValue, label) {
  // Guard clauses: handle the bad cases first, happy path last.
  if (rawValue === undefined || rawValue === null) {
    return { value: null, error: `${label} is missing` };
  }
  if (typeof rawValue === 'number') {
    return Number.isFinite(rawValue)
      ? { value: rawValue, error: null }
      : { value: null, error: `${label} is not a finite number` };
  }
  if (typeof rawValue !== 'string') {
    return { value: null, error: `${label} has unsupported type ${typeof rawValue}` };
  }

  const text = rawValue.trim();
  if (text === '') {
    // NOTE: Number('') === 0, which would silently turn "missing" into 0!
    return { value: null, error: `${label} is missing (empty string)` };
  }
  if (!NUMERIC_PATTERN.test(text)) {
    return { value: null, error: `${label} ("${rawValue}") is not a valid number` };
  }
  return { value: Number(text), error: null }; // explicit conversion
}

// Converts 'true'/'false' (any case) or a real boolean. Anything else is invalid.
// We cannot use Boolean('false') because every non-empty string is truthy.
function convertToBoolean(rawValue, label) {
  if (typeof rawValue === 'boolean') return { value: rawValue, error: null };
  if (typeof rawValue === 'string') {
    const text = rawValue.trim().toLowerCase();
    if (text === 'true') return { value: true, error: null };
    if (text === 'false') return { value: false, error: null };
  }
  return { value: null, error: `${label} must be 'true' or 'false'` };
}

// switch is used here: several exact-match cases fall through to one result.
function isSupportedProgram(program) {
  switch (program) {
    case 'BSCS':
    case 'BSSE':
    case 'BSAI':
    case 'BSDS':
      return true;
    default:
      return false;
  }
}

// ---- Step 1: sanitize + validate one applicant ------------------------------
// Never mutates the source object; returns a brand-new cleaned object.
function sanitizeApplicant(applicant) {
  if (applicant === null || typeof applicant !== 'object') {
    return { isValid: false, errors: ['Applicant record is missing or not an object'], data: null };
  }

  const errors = [];

  // Truthy/falsy: an empty string, undefined and null are falsy -> "missing".
  const id = String(applicant.id ?? '').trim();
  if (!id) errors.push('id is missing');

  const name = typeof applicant.name === 'string' ? applicant.name.trim() : '';
  if (!name) errors.push('name is missing');

  // Age: must be an integer between 17 and 30 (inclusive).
  const age = convertToNumber(applicant.age, 'age');
  if (age.error) {
    errors.push(age.error);
  } else if (!Number.isInteger(age.value) || age.value < AGE_MIN || age.value > AGE_MAX) {
    errors.push(`age (${age.value}) must be a whole number between ${AGE_MIN} and ${AGE_MAX}`);
  }

  // Marks: loop over the three mark fields.
  const marks = {};
  for (const field of MARK_FIELDS) {
    const converted = convertToNumber(applicant[field], field);
    if (converted.error) {
      errors.push(converted.error);
    } else if (converted.value < MARKS_MIN || converted.value > MARKS_MAX) {
      errors.push(`${field} (${converted.value}) must be between ${MARKS_MIN} and ${MARKS_MAX}`);
    } else {
      marks[field] = converted.value;
    }
  }

  // Program
  const program = typeof applicant.program === 'string' ? applicant.program.trim().toUpperCase() : '';
  if (!program) {
    errors.push('program is missing');
  } else if (!isSupportedProgram(program)) {
    errors.push(`program "${applicant.program}" is not supported`);
  }

  // Fee
  const fee = convertToBoolean(applicant.feePaid, 'feePaid');
  if (fee.error) errors.push(fee.error);

  if (errors.length > 0) return { isValid: false, errors, data: null };

  return {
    isValid: true,
    errors: [],
    data: { id, name, age: age.value, program, feePaid: fee.value, ...marks },
  };
}

// ---- Step 2: merit (only called for VALID data) ------------------------------
// Integer arithmetic first, divide once at the end -> no floating point drift
// (e.g. exactly 70 stays 70 and the >= 70 boundary is reliable).
function calculateMerit({ matricMarks, intermediateMarks, entryTest }) {
  const weighted =
    matricMarks * WEIGHTS.matricMarks +
    intermediateMarks * WEIGHTS.intermediateMarks +
    entryTest * WEIGHTS.entryTest;
  return Math.round(weighted) / 100; // 2 decimal places
}

// ---- Step 3: decision --------------------------------------------------------
function decideStatus(data, merit) {
  const eligible =
    merit >= MIN_MERIT &&
    data.entryTest >= MIN_ENTRY_TEST &&
    data.intermediateMarks >= MIN_INTERMEDIATE;

  if (!eligible) {
    return { status: STATUS.REJECTED, reason: describeRejection(data, merit) };
  }

  const isSelected = merit >= SELECTION_MERIT && data.feePaid;
  const status = isSelected ? STATUS.SELECTED : STATUS.WAITING; // ternary
  const reason = isSelected
    ? 'Eligible, merit >= 75 and fee paid'
    : merit < SELECTION_MERIT
      ? 'Eligible, but merit is below 75 (waiting list)'
      : 'Eligible, but fee is not paid yet';
  return { status, reason };
}

function describeRejection(data, merit) {
  const reasons = [];
  if (merit < MIN_MERIT) reasons.push(`merit ${merit} < ${MIN_MERIT}`);
  if (data.entryTest < MIN_ENTRY_TEST) reasons.push(`entry test ${data.entryTest} < ${MIN_ENTRY_TEST}`);
  if (data.intermediateMarks < MIN_INTERMEDIATE) {
    reasons.push(`intermediate ${data.intermediateMarks} < ${MIN_INTERMEDIATE}`);
  }
  return reasons.join('; ');
}

// ---- Process ONE applicant ----------------------------------------------------
function processApplicant(applicant) {
  const { isValid, errors, data } = sanitizeApplicant(applicant);

  // Guard clause: merit is NEVER calculated for invalid applications.
  if (!isValid) {
    return {
      id: applicant?.id ?? 'UNKNOWN',
      name: applicant?.name ?? 'UNKNOWN',
      program: typeof applicant?.program === 'string' ? applicant.program.trim().toUpperCase() : null,
      merit: null,
      status: STATUS.INVALID,
      reason: errors.join('; '),
    };
  }

  const merit = calculateMerit(data);
  const { status, reason } = decideStatus(data, merit);
  return { id: data.id, name: data.name, program: data.program, merit, status, reason };
}

// ---- Process ALL applicants ----------------------------------------------------
function processApplicants(applicants) {
  if (!Array.isArray(applicants)) {
    throw new TypeError('applicants must be an array');
  }
  return applicants.map(processApplicant); // new array, source untouched
}

// ---- Final summary --------------------------------------------------------------
function summarize(results) {
  const valid = results.filter((r) => r.status !== STATUS.INVALID);
  const invalidCount = results.length - valid.length;

  let highest = null;
  let lowest = null;
  let meritTotal = 0;
  for (const applicant of valid) {
    if (highest === null || applicant.merit > highest.merit) highest = applicant;
    if (lowest === null || applicant.merit < lowest.merit) lowest = applicant;
    meritTotal += applicant.merit;
  }

  const perProgram = {};
  for (const r of results) {
    const key = r.program && isSupportedProgram(r.program) ? r.program : 'UNSUPPORTED/MISSING';
    perProgram[key] = (perProgram[key] ?? 0) + 1;
  }

  return {
    validApplicants: valid.length,
    invalidApplicants: invalidCount,
    highestMerit: highest ? { id: highest.id, name: highest.name, merit: highest.merit } : null,
    lowestMerit: lowest ? { id: lowest.id, name: lowest.name, merit: lowest.merit } : null,
    averageMerit: valid.length > 0 ? Math.round((meritTotal / valid.length) * 100) / 100 : null,
    applicantsPerProgram: perProgram,
  };
}

// =============================================================================
// DEMO: normal, boundary and invalid test cases
// =============================================================================
const applicants = [
  { id: 'A101', name: 'Sara Khan', age: '19', matricMarks: '91', intermediateMarks: '87', entryTest: '78', program: 'BSCS', feePaid: 'true' },
  { id: 'A102', name: 'Ahmed Ali', age: 'twenty', matricMarks: '88', intermediateMarks: '', entryTest: '72', program: 'BSSE', feePaid: 'false' },
  { id: 'A103', name: 'Hassan', age: '18', matricMarks: '76', intermediateMarks: '83', entryTest: '91', program: 'BSAI', feePaid: 'true' },

  // ---- boundary cases ----
  { id: 'B201', name: 'Exactly 70', age: '17', matricMarks: '70', intermediateMarks: '70', entryTest: '70', program: 'BSCS', feePaid: 'true' },      // merit 70 -> WAITING (age 17 is valid)
  { id: 'B202', name: 'Entry 59', age: '30', matricMarks: '100', intermediateMarks: '100', entryTest: '59', program: 'BSSE', feePaid: 'true' },        // entry test < 60 -> REJECTED (age 30 valid)
  { id: 'B203', name: 'Entry 60', age: '20', matricMarks: '100', intermediateMarks: '100', entryTest: '60', program: 'bsai', feePaid: 'true' },        // lower-case program is normalised; merit 80 -> SELECTED
  { id: 'B204', name: 'Unpaid Fee', age: '21', matricMarks: '95', intermediateMarks: '95', entryTest: '95', program: 'BSDS', feePaid: 'false' },      // eligible but unpaid -> WAITING
  { id: 'B205', name: 'All Zero', age: '22', matricMarks: '0', intermediateMarks: '0', entryTest: '0', program: 'BSCS', feePaid: 'true' },            // 0 is a VALID mark -> REJECTED (not invalid)
  { id: 'B206', name: 'Low Merit', age: '22', matricMarks: '40', intermediateMarks: '60', entryTest: '60', program: 'BSCS', feePaid: 'true' },        // merit 56 -> REJECTED

  // ---- invalid cases ----
  { id: 'C301', name: 'Too Young', age: '16', matricMarks: '80', intermediateMarks: '80', entryTest: '80', program: 'BSCS', feePaid: 'true' },
  { id: 'C302', name: 'Too Old', age: '31', matricMarks: '80', intermediateMarks: '80', entryTest: '80', program: 'BSCS', feePaid: 'true' },
  { id: 'C303', name: 'Marks 101', age: '20', matricMarks: '101', intermediateMarks: '80', entryTest: '80', program: 'BSCS', feePaid: 'true' },
  { id: 'C304', name: 'Negative', age: '20', matricMarks: '-5', intermediateMarks: '80', entryTest: '80', program: 'BSCS', feePaid: 'true' },
  { id: 'C305', name: 'Bad Program', age: '20', matricMarks: '80', intermediateMarks: '80', entryTest: '80', program: 'BBA', feePaid: 'true' },
  { id: 'C306', name: 'Bad Number', age: '20', matricMarks: '8O', intermediateMarks: '80', entryTest: '80', program: 'BSCS', feePaid: 'true' },
  { id: 'C307', name: 'Bad Fee', age: '20', matricMarks: '80', intermediateMarks: '80', entryTest: '80', program: 'BSCS', feePaid: 'maybe' },
  { id: 'C308', name: 'Decimal Age', age: '19.5', matricMarks: '80', intermediateMarks: '80', entryTest: '80', program: 'BSCS', feePaid: 'true' },
  { id: 'C309', name: 'Missing Fields' },
  null,
];

const snapshotBefore = JSON.stringify(applicants);
const results = processApplicants(applicants);

console.log('=== TASK 1: Admission results ===');
console.table(results.map(({ id, name, program, merit, status }) => ({ id, name, program, merit, status })));

console.log('\n--- Reasons ---');
for (const r of results) {
  console.log(`${String(r.id).padEnd(8)} ${r.status.padEnd(13)} ${r.reason}`);
}

console.log('\n=== Summary ===');
console.log(summarize(results));

console.log('\nSource data unchanged?', JSON.stringify(applicants) === snapshotBefore);

// ---- Short demonstration of scope + truthy/falsy (explicit, as asked) ---------
function demonstrateScopeAndTruthiness() {
  console.log('\n=== Scope & truthy/falsy demo ===');
  if (true) {
    var functionScoped = 'var leaks out of the block';
    let blockScoped = 'let stays inside the block';
    console.log(blockScoped);
  }
  console.log(functionScoped);
  // console.log(blockScoped); // would throw ReferenceError - not in scope here

  const samples = [0, '0', '', ' ', null, undefined, NaN, 'false', []];
  for (const value of samples) {
    console.log(`${inspect(value)} (${typeof value}) is ${value ? 'truthy' : 'falsy'}`);
  }
  console.log("Number('') =", Number(''), "| Number('abc') =", Number('abc'), "| '5' + 1 =", '5' + 1, "| '5' - 1 =", '5' - 1);
  console.log("0 == '' ->", 0 == '', "| 0 === '' ->", 0 === '');
}
demonstrateScopeAndTruthiness();
