// =============================================================================
// Task 3 - Safe Student Profile Update Service
// Demonstrates: object destructuring, nested destructuring, renaming, default
// values, array destructuring, rest parameters, object rest, spread,
// optional chaining (?.), nullish coalescing (??), property shorthand.
// The original student is NEVER modified.
// =============================================================================

const student = {
  id: 101,
  name: 'Ali',
  marks: 0,
  scholarship: false,
  address: { city: 'Islamabad', sector: 'F-10' },
  contact: { email: 'ali@university.edu' },
};

const update = {
  name: 'Ali Khan',
  address: { city: 'Rawalpindi' },
  contact: { phone: '03001234567' },
};

// ---- Helper: drop ONLY undefined / null values ------------------------------
// 0, false and '' are VALID values and must survive. That is why we compare
// with `=== undefined` / `=== null` (or use ??) and NOT with a truthy check
// like `if (value)` or `value || default`, which would wrongly discard them.
function withoutNullish(patch = {}) {
  return Object.fromEntries(
    Object.entries(patch).filter(([, value]) => value !== undefined && value !== null),
  );
}

// ---- The update service --------------------------------------------------------
// Default value (update = {}) -> calling with no update is safe.
function updateStudent(currentStudent, patch = {}) {
  // Object destructuring + RENAMING (id -> ignoredId: ids are never changed)
  // + DEFAULT VALUES (address/contact default to {} when not in the patch)
  // + OBJECT REST (simpleFields collects every other field of the patch).
  const {
    id: ignoredId,
    address: addressPatch = {},
    contact: contactPatch = {},
    ...simpleFields
  } = patch;

  // SPREAD builds NEW objects at every level that can change, so nothing is
  // shared with the original. Later spreads override earlier ones.
  return {
    ...currentStudent,
    ...withoutNullish(simpleFields),
    address: { ...currentStudent.address, ...withoutNullish(addressPatch) },
    contact: { ...currentStudent.contact, ...withoutNullish(contactPatch) },
  };
}

// ---- REST PARAMETERS: apply any number of updates one after another -------------
function applyUpdates(currentStudent, ...patches) {
  return patches.reduce((latest, patch) => updateStudent(latest, patch), currentStudent);
}

// ---- NESTED destructuring in the parameter list + defaults + renaming ----------
function describeStudent({
  id,
  name: fullName,                                  // renaming
  marks = 0,                                       // default (only used if undefined)
  address: { city = 'Unknown city', sector = '-' } = {},   // nested + defaults
  contact: { email = 'no email', phone = 'no phone' } = {},
}) {
  // ARRAY destructuring + rest: first word is first name, remaining words = surname
  const [firstName, ...surnameParts] = fullName.split(' ');
  const surname = surnameParts.join(' ') || '(none)';
  return `#${id} ${firstName} | surname: ${surname} | marks: ${marks} | ${city}, ${sector} | ${email} | ${phone}`;
}

// Property shorthand: { original, updated } instead of { original: original, ... }
function compareReferences(original, updated) {
  const sameObject = original === updated;
  const sameAddress = original.address === updated.address;
  const sameContact = original.contact === updated.contact;
  return { sameObject, sameAddress, sameContact };
}

// =============================================================================
// DEMO
// =============================================================================
const before = JSON.stringify(student);
const updated = updateStudent(student, update);

console.log('=== Original (must stay untouched) ===');
console.log(student);
console.log('\n=== Updated copy ===');
console.log(updated);
console.log('\nOriginal unchanged?', JSON.stringify(student) === before);

console.log('\n=== Checks ===');
console.log('name changed         :', updated.name === 'Ali Khan');
console.log('marks kept (0)       :', updated.marks === 0);
console.log('scholarship kept     :', updated.scholarship === false);
console.log('city changed         :', updated.address.city);
console.log('sector kept          :', updated.address.sector);
console.log('email kept           :', updated.contact.email);
console.log('phone added          :', updated.contact.phone);

console.log('\n=== Falsy-but-valid values (0, false, \'\') are NOT replaced ===');
const strong = { id: 7, name: 'Zara', marks: 85, scholarship: true, address: { city: 'Lahore' }, contact: {} };
const zeroed = updateStudent(strong, { marks: 0, scholarship: false, name: '' });
console.log(zeroed);
console.log('A "|| default" implementation would have broken it:', { marks: 0 || 85, scholarship: false || true });
const ignoredNullish = updateStudent(strong, { marks: null, name: undefined });
console.log('null / undefined are ignored (keep old):', ignoredNullish.marks, ignoredNullish.name);
console.log('id cannot be changed:', updateStudent(strong, { id: 999 }).id);
console.log('Empty / missing update is safe:', updateStudent(strong).name, '| student without address:', updateStudent({ id: 1, name: 'X' }, { address: { city: 'Y' } }));

console.log('\n=== Optional chaining + nullish coalescing ===');
console.log('phone of original :', student.contact?.phone ?? 'No phone on file');
console.log('phone of updated  :', updated.contact?.phone ?? 'No phone on file');
console.log('guardian city     :', student.guardian?.address?.city ?? 'No guardian recorded'); // no TypeError
console.log('student.marks ?? 50 ->', student.marks ?? 50, '| student.marks || 50 ->', student.marks || 50);

console.log('\n=== describeStudent (nested destructuring) ===');
console.log(describeStudent(student));
console.log(describeStudent(updated));
console.log(describeStudent({ id: 2, name: 'Noor' })); // defaults kick in

console.log('\n=== Rest parameters: several updates in order ===');
const multi = applyUpdates(student, { name: 'Ali K.' }, { address: { sector: 'G-11' } }, { marks: 55 });
console.log(multi);

console.log('\n=== Reference challenge ===');
const refs = compareReferences(student, updated);
console.log(refs);
console.log(`original vs updated object : ${refs.sameObject ? 'EQUAL' : 'DIFFERENT'} -> the spread created a brand-new top-level object.`);
console.log(`original vs updated address: ${refs.sameAddress ? 'EQUAL' : 'DIFFERENT'} -> address was rebuilt with { ...old, ...patch }, so it is a new object.`);
console.log(`original vs updated contact: ${refs.sameContact ? 'EQUAL' : 'DIFFERENT'} -> contact was rebuilt as well, so it is a new object.`);
console.log('Objects are compared by REFERENCE (memory address), not by content: two objects with identical content are still !==.');
console.log('{a:1} === {a:1} ->', { a: 1 } === { a: 1 });

console.log('\n=== Why a plain (shallow) spread is NOT enough ===');
const shallow = { ...student, name: 'Shallow' };
console.log('shallow.address === student.address ->', shallow.address === student.address, '(SAME reference!)');
shallow.address.city = 'OOPS';
console.log('Mutating the shallow copy changed the original city to:', student.address.city);
student.address.city = 'Islamabad'; // restore for the checks below
console.log('Our updateStudent() never shares nested objects, so this bug cannot happen.');

// Property shorthand demo
const { id, name } = updated;
console.log('\nShorthand object:', { id, name });
