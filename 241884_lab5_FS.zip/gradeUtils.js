// gradeUtils.js - named exports only.

const PASS_MARKS = 50;

// Highest band first.
const GRADE_SCALE = [
  { min: 85, grade: 'A', points: 4.0 },
  { min: 80, grade: 'A-', points: 3.67 },
  { min: 75, grade: 'B+', points: 3.33 },
  { min: 70, grade: 'B', points: 3.0 },
  { min: 65, grade: 'B-', points: 2.67 },
  { min: 60, grade: 'C+', points: 2.33 },
  { min: 50, grade: 'C', points: 2.0 },
  { min: 0, grade: 'F', points: 0.0 },
];

const round2 = (value) => Math.round(value * 100) / 100;

function assertMarks(marks) {
  if (typeof marks !== 'number' || Number.isNaN(marks)) {
    throw new TypeError(`Marks must be a number, received ${typeof marks}`);
  }
  if (marks < 0 || marks > 100) {
    throw new RangeError(`Marks must be between 0 and 100, received ${marks}`);
  }
}

// Returns { grade, points, passed } for one course mark.
export function calculateGrade(marks) {
  assertMarks(marks);
  const { grade, points } = GRADE_SCALE.find((band) => marks >= band.min);
  return { grade, points, passed: marks >= PASS_MARKS };
}

// Average of an array of marks. Empty array -> 0 (a student with no courses yet).
export function calculateAverage(marksList) {
  if (!Array.isArray(marksList)) throw new TypeError('calculateAverage expects an array of marks');
  if (marksList.length === 0) return 0;
  marksList.forEach(assertMarks);
  return round2(marksList.reduce((sum, marks) => sum + marks, 0) / marksList.length);
}

// GPA = average of the grade points of every course (all courses weigh equally).
export function calculateGPA(marksList) {
  if (!Array.isArray(marksList)) throw new TypeError('calculateGPA expects an array of marks');
  if (marksList.length === 0) return 0;
  const totalPoints = marksList.reduce((sum, marks) => sum + calculateGrade(marks).points, 0);
  return round2(totalPoints / marksList.length);
}

export { PASS_MARKS };
