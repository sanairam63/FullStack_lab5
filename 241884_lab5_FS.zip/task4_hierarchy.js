node // =============================================================================
// Task 4 - University User Hierarchy and Dynamic `this`
//
//   Person
//     |-- Student
//     |-- FacultyMember
//
// No closures are used anywhere in this file.
// =============================================================================

// `class` is syntax over constructor functions + prototypes.
class Person {
  // constructor: runs automatically when `new Person(...)` is evaluated.
  // `this` is the brand-new object being created.
  constructor(name, email) {
    this.name = name;
    this.email = email;
  }

  introduce() {
    return `Hello, I am ${this.name} (${this.email}).`;
  }
}

// `extends` links Student.prototype -> Person.prototype (the prototype chain).
class Student extends Person {
  constructor(name, email, rollNo, marks) {
    // super(...) MUST be called before `this` is touched in a subclass.
    // It runs the parent constructor, which sets name and email.
    super(name, email);
    this.rollNo = rollNo;
    this.marks = marks;
  }

  // METHOD OVERRIDING: same name as Person.introduce(), different behaviour.
  // super.introduce() REUSES the parent's text instead of copy-pasting it.
  introduce() {
    return `${super.introduce()} I am a student, roll number ${this.rollNo}.`;
  }

  getResult() {
    if (typeof this.marks !== 'number' || this.marks < 0 || this.marks > 100) {
      return `${this.name}: INVALID MARKS`;
    }
    return `${this.name} (${this.rollNo}): ${this.marks} marks -> ${this.marks >= 50 ? 'PASS' : 'FAIL'}`;
  }
}

class FacultyMember extends Person {
  constructor(name, email, employeeId, department) {
    super(name, email);
    this.employeeId = employeeId;
    this.department = department;
  }

  introduce() {
    return `${super.introduce()} I teach in the ${this.department} department (employee ${this.employeeId}).`;
  }
}

// =============================================================================
// RUNTIME POLYMORPHISM
// One array, different kinds of objects, same call. The method that actually
// runs is chosen at RUNTIME from the real object's prototype chain.
// =============================================================================
const users = [
  new Student('Ali', 'ali@au.edu.pk', '23F-0101', 82),
  new FacultyMember('Dr. Sana', 'sana@au.edu.pk', 'E-501', 'Computer Science'),
  new Student('Hina', 'hina@au.edu.pk', '23F-0102', 47),
  new Person('Visitor', 'visitor@example.com'),
  new FacultyMember('Dr. Omar', 'omar@au.edu.pk', 'E-502', 'Software Engineering'),
];

console.log('=== Runtime polymorphism ===');
users.forEach((user) => console.log(user.introduce()));

console.log('\n=== instanceof & prototype chain ===');
const ali = users[0];
const sana = users[1];
console.log('ali instanceof Student        :', ali instanceof Student);
console.log('ali instanceof Person         :', ali instanceof Person);
console.log('ali instanceof FacultyMember  :', ali instanceof FacultyMember);
console.log('sana instanceof Student       :', sana instanceof Student);
console.log('Object.getPrototypeOf(ali) === Student.prototype :', Object.getPrototypeOf(ali) === Student.prototype);
console.log('Student.prototype -> Person.prototype            :', Object.getPrototypeOf(Student.prototype) === Person.prototype);
console.log('ali has OWN introduce()?', Object.hasOwn(ali, 'introduce'), '(no - it lives on Student.prototype)');

console.log('\n=== Student-only behaviour (check type first) ===');
users
  .filter((user) => user instanceof Student)
  .forEach((student) => console.log(student.getResult()));

console.log('\n=== `new` is required ===');
try {
  Person('No new', 'x@y.z'); // class constructors cannot be called without new
} catch (error) {
  console.log(`${error.name}: ${error.message}`);
}

// =============================================================================
// this, call() and bind()
//
// `this` is NOT decided where a function is written; it is decided by HOW the
// function is CALLED:
//   obj.method()      -> this = obj
//   fn()              -> this = undefined (strict mode / class bodies)
//   fn.call(x, ...)   -> this = x (calls immediately)
//   fn.bind(x)        -> returns a NEW function whose this is permanently x
//   new Fn()          -> this = the newly created object
// =============================================================================
const guest = {
  name: 'Dr. Ahmed',
  email: 'ahmed@example.com',
};

console.log('\n=== call(): borrow Person.introduce for a plain object ===');
// guest is not a Person, but it has name and email, so introduce() works on it.
console.log(Person.prototype.introduce.call(guest));
// call() with extra args would be: fn.call(thisValue, arg1, arg2); apply() takes an array.

console.log('\n=== Detached method: this is lost ===');
const student = ali;
console.log('student.introduce() ->', student.introduce()); // method call: this = student

const fn = student.introduce; // we only copied the function, NOT the object
try {
  console.log(fn()); // plain call -> this === undefined (class code is strict)
} catch (error) {
  console.log(`fn() failed -> ${error.name}: ${error.message}`);
}
console.log('Reason: fn() has no object before the dot, so this is undefined and this.name / this.rollNo cannot be read.');

// In sloppy-mode (non-strict) scripts a detached function would get globalThis
// as `this` and quietly give "undefined" values instead of throwing. ES modules
// and class bodies are always strict, so we get undefined / a TypeError instead.
function plainFunction() {
  return `this is ${this === undefined ? 'undefined (strict mode)' : 'something else'}`;
}
console.log('Plain function called on its own:', plainFunction());

console.log('\n=== bind(): permanently fixed this ===');
const safeIntroduce = student.introduce.bind(student);
console.log('safeIntroduce() ->', safeIntroduce());

// Typical real use: passing a method as a callback.
// setTimeout(student.introduce, 10)  -> this would be lost (Timeout object in Node)
// setTimeout(safeIntroduce, 10)      -> works
setTimeout(safeIntroduce, 10);
setTimeout(console.log, 20, '(callback via bound method ran fine, see above)');

// bind() can also lend a method to another object, permanently:
const guestIntroduce = Person.prototype.introduce.bind(guest);
console.log('guestIntroduce() ->', guestIntroduce());

// A bound function ignores later call(): this stays the bound object.
console.log('Rebinding with call() has no effect:', safeIntroduce.call(guest));
