// =============================================================================
// Task 7 - Promise-Based Multi-Service Registration Engine
//
// Part A: Promise chain  getStudent -> getCourse -> checkPrerequisites
//                        -> checkSeats -> registerStudent
// Part B: Promise.allSettled for email / SMS / audit log
// Part C: Promise.any for "first SUCCESSFUL" server (compared with race)
//
// Data travels from stage to stage in a context object `ctx`. Every stage
// receives the previous ctx and RETURNS a new ctx with something added.
// No closures are created as a technique: stages are plain top-level functions.
// =============================================================================

// ---- Fake data ---------------------------------------------------------------------
const STUDENTS = {
  101: { id: 101, name: 'Ali', email: 'ali@au.edu.pk', phone: null, completed: ['CS101', 'CS201'] }, // no phone -> SMS fails
  102: { id: 102, name: 'Sara', email: 'sara@au.edu.pk', phone: '03001234567', completed: ['CS101', 'CS201'] },
  103: { id: 103, name: 'Hina', email: 'hina@au.edu.pk', phone: '03007654321', completed: ['CS101'] },
};
const COURSES = {
  CS401: { code: 'CS401', title: 'Advanced Web', prerequisites: ['CS201'], seats: 1 },
  CS402: { code: 'CS402', title: 'Databases', prerequisites: ['CS101'], seats: 5 },
};
const REGISTRATIONS = [];

// ---- Promise creation: explicit resolve() / reject() ----------------------------------
// `producer(...args)` does the work synchronously; if it throws, the Promise
// rejects, otherwise it resolves with the returned value - after `ms` delay.
function respondAfter(ms, producer, ...args) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        resolve(producer(...args));
      } catch (error) {
        reject(error);
      }
    }, ms);
  });
}

// ---- Services (each returns a Promise of the NEW context) --------------------------------
function getStudent(ctx) {
  return respondAfter(40, lookupStudent, ctx);
}
function lookupStudent(ctx) {
  const student = STUDENTS[ctx.studentId];
  if (!student) throw new Error(`Student ${ctx.studentId} not found`);
  return { ...ctx, student };
}

function getCourse(ctx) {
  return respondAfter(40, lookupCourse, ctx);
}
function lookupCourse(ctx) {
  const course = COURSES[ctx.courseCode];
  if (!course) throw new Error(`Course ${ctx.courseCode} not found`);
  return { ...ctx, course };
}

function checkPrerequisites(ctx) {
  return respondAfter(40, verifyPrerequisites, ctx);
}
function verifyPrerequisites(ctx) {
  const missing = ctx.course.prerequisites.filter((code) => !ctx.student.completed.includes(code));
  if (missing.length > 0) throw new Error(`Missing prerequisites: ${missing.join(', ')}`);
  return ctx;
}

function checkSeats(ctx) {
  return respondAfter(40, verifySeats, ctx);
}
function verifySeats(ctx) {
  if (ctx.course.seats <= 0) throw new Error(`Course ${ctx.course.code} is full`);
  return ctx;
}

function registerStudent(ctx) {
  return respondAfter(40, saveRegistration, ctx);
}
function saveRegistration(ctx) {
  const key = `${ctx.student.id}:${ctx.course.code}`;
  if (REGISTRATIONS.includes(key)) throw new Error('Student is already registered');
  REGISTRATIONS.push(key);
  ctx.course.seats -= 1;
  return { ...ctx, confirmation: { studentId: ctx.student.id, course: ctx.course.code, status: 'REGISTERED' } };
}

// Post-registration services (independent of each other)
function sendEmail(ctx) {
  return respondAfter(60, deliverEmail, ctx);
}
function deliverEmail(ctx) {
  if (!ctx.student.email) throw new Error('No e-mail address');
  return `E-mail sent to ${ctx.student.email}`;
}
function sendSMS(ctx) {
  return respondAfter(30, deliverSms, ctx);
}
function deliverSms(ctx) {
  if (!ctx.student.phone) throw new Error('No phone number on file');
  return `SMS sent to ${ctx.student.phone}`;
}
function writeAuditLog(ctx) {
  return respondAfter(80, appendAudit, ctx);
}
function appendAudit(ctx) {
  return `Audit: ${ctx.confirmation.studentId} -> ${ctx.confirmation.course}`;
}

// =============================================================================
// PART A - the registration chain
// =============================================================================
// Every .then() receives the previous stage's result and RETURNS the next
// Promise. Returning a Promise from .then() makes the chain WAIT for it and
// then pass its resolved value on. Passing the function itself (not wrapping
// it in an arrow function that forgets `return`) keeps the data flowing.
function runRegistrationChain(studentId, courseCode) {
  return Promise.resolve({ studentId, courseCode })
    .then(getStudent)
    .then(getCourse)
    .then(checkPrerequisites)
    .then(checkSeats)
    .then(registerStudent);
}

// The classic BUG: braces without `return` -> the next .then receives undefined
// and does not wait for getCourse() at all.
function brokenRegistrationChain(studentId, courseCode) {
  return Promise.resolve({ studentId, courseCode })
    .then(getStudent)
    .then((ctx) => {
      getCourse(ctx); // <-- missing `return`!
    })
    .then(checkPrerequisites); // receives undefined -> TypeError
}

// =============================================================================
// PART B - Promise.allSettled
// =============================================================================
// Why allSettled? We want the outcome of ALL THREE services even if some fail.
//   Promise.all    -> rejects at the first failure; we would lose the others' results.
//   Promise.race   -> only tells us about the first finished one.
//   Promise.any    -> only wants one success.
const POST_SERVICES = ['Email', 'SMS', 'Audit'];

function runPostRegistrationServices(ctx) {
  return Promise.allSettled([sendEmail(ctx), sendSMS(ctx), writeAuditLog(ctx)]).then(buildServiceReport);
}
function buildServiceReport(outcomes) {
  return outcomes.map((outcome, index) => ({
    service: POST_SERVICES[index],
    status: outcome.status,
    ...(outcome.status === 'fulfilled' ? { value: outcome.value } : { reason: outcome.reason.message }),
  }));
}

// Complete flow: chain + post services, with catch and finally.
function registerAndNotify(studentId, courseCode) {
  console.log(`\n>>> Registering student ${studentId} for ${courseCode}`);
  return runRegistrationChain(studentId, courseCode)
    .then((ctx) => {
      console.log('   Registered:', ctx.confirmation);
      return runPostRegistrationServices(ctx);
    })
    .then((report) => {
      console.log('   Service report:');
      console.table(report);
      return { ok: true, report };
    })
    .catch((error) => {
      // Any rejection from ANY stage of the chain lands here; later stages are skipped.
      console.log(`   FAILED: ${error.message}`);
      return { ok: false, error: error.message };
    })
    .finally(() => {
      // Runs on success AND failure; receives no argument and does not change the result.
      console.log(`<<< Workflow for student ${studentId} / ${courseCode} finished`);
    });
}

// =============================================================================
// PART C - two independent course servers
// =============================================================================
function fetchCourseFromServer(serverName, ms, shouldFail) {
  return new Promise((resolve, reject) => {
    setTimeout(settleServer, ms, serverName, shouldFail, resolve, reject);
  });
}
function settleServer(serverName, shouldFail, resolve, reject) {
  if (shouldFail) reject(new Error(`${serverName} is down`));
  else resolve({ server: serverName, course: COURSES.CS402 });
}

// Promise.any resolves with the first FULFILLED promise and ignores rejections
// (it only rejects - with an AggregateError - when ALL of them reject).
// Promise.race settles with the first SETTLED promise, so a fast failure wins
// and would make CampusFlow fail although another server could answer.
function runServerSelectionDemo() {
  const makeServers = () => [
    fetchCourseFromServer('Server-A', 30, true), //  fails quickly
    fetchCourseFromServer('Server-B', 120, false), // succeeds a bit later
    fetchCourseFromServer('Server-C', 250, false), // succeeds even later
  ];

  console.log('\n=== PART C: server selection ===');
  return Promise.race(makeServers())
    .then((result) => console.log('race  ->', result.server))
    .catch((error) => console.log(`race  -> REJECTED: ${error.message}  (first SETTLED was a failure - wrong choice)`))
    .then(() => Promise.any(makeServers()))
    .then((result) => console.log(`any   -> ${result.server} answered first successfully  (correct choice)`))
    .then(() => Promise.any([fetchCourseFromServer('Server-X', 20, true), fetchCourseFromServer('Server-Y', 40, true)]))
    .catch((error) => console.log(`any with every server down -> ${error.constructor.name}: ${error.errors.map((e) => e.message).join(' | ')}`));
}

// =============================================================================
// DEMO (scenarios run strictly one after another through a chain)
// =============================================================================
console.log('=== PART A + B: registration chain and post-registration services ===');

registerAndNotify(101, 'CS401') // success; SMS rejected (no phone)
  .then(() => registerAndNotify(102, 'CS401')) // course full
  .then(() => registerAndNotify(103, 'CS402')) // prerequisites OK for CS402 (needs CS101) -> success
  .then(() => registerAndNotify(103, 'CS401')) // missing prerequisite
  .then(() => registerAndNotify(999, 'CS401')) // student does not exist
  .then(() => registerAndNotify(101, 'CS999')) // course does not exist
  .then(() => {
    console.log('\n=== Missing `return` bug demo ===');
    return brokenRegistrationChain(102, 'CS402').catch((error) => console.log(`broken chain -> ${error.name}: ${error.message}`));
  })
  .then(runServerSelectionDemo)
  .finally(() => {
    console.log('\nCombinator choices: allSettled (Part B) = need every outcome; any (Part C) = first SUCCESS;');
    console.log('race shown only for contrast; Promise.all is NOT used because one failure must not hide the other results.');
  });
