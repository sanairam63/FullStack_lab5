// transcriptService.js - parse, validate and report on JSON transcript data.
//
// Error types used (and why):
//   SyntaxError - malformed JSON text (what JSON.parse itself throws)
//   TypeError   - wrong SHAPE/TYPE of data (not an array, id missing, code missing,
//                 marks not a number)
//   RangeError  - a number that is the right type but outside the allowed range
//                 (marks < 0 or > 100)
//   Error       - business-rule violation (duplicate student id)
import Student from './Student.js';
import { calculateAverage } from './gradeUtils.js';

const isMissing = (value) => value === undefined || value === null || (typeof value === 'string' && value.trim() === '');

// 1. Parse JSON safely ---------------------------------------------------------
export function parseTranscriptJson(rawText) {
  if (typeof rawText !== 'string') {
    throw new TypeError(`Transcript data must be a JSON string, received ${typeof rawText}`);
  }
  try {
    return JSON.parse(rawText);
  } catch (error) {
    // Re-throw with a clearer message but keep the original as `cause`.
    throw new SyntaxError(`Malformed transcript JSON: ${error.message}`, { cause: error });
  }
}

// 2. Validate one course -----------------------------------------------------------
function validateCourse(course, studentLabel, index) {
  if (course === null || typeof course !== 'object') {
    throw new TypeError(`${studentLabel}: course #${index + 1} is not an object`);
  }
  if (isMissing(course.code)) {
    throw new TypeError(`${studentLabel}: course #${index + 1} has a missing course code`);
  }
  if (typeof course.marks !== 'number' || Number.isNaN(course.marks)) {
    throw new TypeError(`${studentLabel}: marks for ${course.code} must be a number`);
  }
  if (course.marks < 0 || course.marks > 100) {
    throw new RangeError(`${studentLabel}: marks for ${course.code} (${course.marks}) must be between 0 and 100`);
  }
}

// 3. Validate every student; return Student instances ----------------------------------
export function validateTranscripts(data) {
  if (!Array.isArray(data)) {
    throw new TypeError('Transcript data must be a JSON array of students');
  }

  const seenIds = new Set();
  return data.map((record, position) => {
    if (record === null || typeof record !== 'object') {
      throw new TypeError(`Record #${position + 1} is not an object`);
    }
    const { id, name, courses = [] } = record;
    if (isMissing(id)) {
      throw new TypeError(`Record #${position + 1} has a missing student id`);
    }
    if (seenIds.has(id)) {
      throw new Error(`Duplicate student id: ${id}`);
    }
    seenIds.add(id);

    if (!Array.isArray(courses)) {
      throw new TypeError(`Student ${id}: courses must be an array`);
    }
    const label = `Student ${id}`;
    courses.forEach((course, index) => validateCourse(course, label, index));

    return new Student(id, name, courses);
  });
}

// 4. Build the JavaScript report object -----------------------------------------------------
export function buildReport(students) {
  const entries = students.map((student) => student.toReportEntry());
  return {
    studentCount: entries.length,
    // Only students that actually have courses count towards the class average.
    classAverage: calculateAverage(entries.filter((entry) => entry.courses.length > 0).map((entry) => entry.average)),
    students: entries,
  };
}

// 5. Convert the report back to JSON --------------------------------------------------------
export function reportToJson(report) {
  return JSON.stringify(report, null, 2);
}

// Convenience: raw JSON text -> report object (throws on any problem).
export function processTranscript(rawText) {
  return buildReport(validateTranscripts(parseTranscriptJson(rawText)));
}
