// =============================================================================
// Task 6 - Legacy Course Registration Service Using Callbacks
//
//   Load Student -> Check Prerequisites -> Check Seats -> Register Course
//
// Rules followed:
//   * error-first callbacks:  callback(error, value)
//   * every async operation calls its callback EXACTLY ONCE (note the `return`
//     after every callback(error, ...) call)
//   * errors are returned through the callback, never thrown asynchronously
//   * the workflow stops at the first failing stage
//   * NO Promises, NO async/await
//   * NO closures: state travels in an explicit `state` object. setTimeout's
//     extra arguments (setTimeout(fn, ms, arg1, arg2)) hand that state to the
//     next step, so the handlers are plain top-level functions that do not
//     capture variables from an outer function.
// =============================================================================

// ---- Fake "legacy" database ------------------------------------------------------
const database = {
  students: {
    101: { id: 101, name: 'Ali', completed: ['CS101', 'CS201'] },
    102: { id: 102, name: 'Sara', completed: ['CS101', 'CS201'] },
    103: { id: 103, name: 'Hina', completed: ['CS101'] },
  },
  courses: {
    CS401: { code: 'CS401', prerequisites: ['CS201'], seats: 1 },
    CS402: { code: 'CS402', prerequisites: ['CS101'], seats: 2 },
  },
  registrations: [], // entries like '101:CS401'
};

const DELAY_MS = 40;

class RegistrationError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'RegistrationError';
    this.code = code;
  }
}

// ---- The four asynchronous operations -----------------------------------------------
// Each one: (state, callback). It schedules work with setTimeout and later calls
// callback(error, state) once. On error `state` is still passed so the handler
// can reach state.done.

function loadStudent(state, callback) {
  setTimeout(finishLoadStudent, DELAY_MS, state, callback);
}
function finishLoadStudent(state, callback) {
  const student = database.students[state.studentId];
  if (!student) {
    callback(new RegistrationError('STUDENT_NOT_FOUND', `Student ${state.studentId} does not exist`), state);
    return; // never fall through to a second callback call
  }
  state.student = student;
  callback(null, state);
}

function checkPrerequisites(state, callback) {
  setTimeout(finishCheckPrerequisites, DELAY_MS, state, callback);
}
function finishCheckPrerequisites(state, callback) {
  const course = database.courses[state.courseCode];
  if (!course) {
    callback(new RegistrationError('COURSE_NOT_FOUND', `Course ${state.courseCode} does not exist`), state);
    return;
  }
  const missing = course.prerequisites.filter((code) => !state.student.completed.includes(code));
  if (missing.length > 0) {
    callback(new RegistrationError('PREREQUISITE_MISSING', `${state.student.name} has not completed: ${missing.join(', ')}`), state);
    return;
  }
  state.course = course;
  callback(null, state);
}

function checkSeats(state, callback) {
  setTimeout(finishCheckSeats, DELAY_MS, state, callback);
}
function finishCheckSeats(state, callback) {
  if (state.course.seats <= 0) {
    callback(new RegistrationError('COURSE_FULL', `Course ${state.course.code} is full`), state);
    return;
  }
  callback(null, state);
}

function registerCourse(state, callback) {
  setTimeout(finishRegisterCourse, DELAY_MS, state, callback);
}
function finishRegisterCourse(state, callback) {
  const key = `${state.student.id}:${state.course.code}`;
  if (database.registrations.includes(key)) {
    callback(new RegistrationError('ALREADY_REGISTERED', `${state.student.name} is already registered for ${state.course.code}`), state);
    return;
  }
  database.registrations.push(key);
  state.course.seats -= 1;
  state.confirmation = { studentId: state.student.id, course: state.course.code, status: 'REGISTERED' };
  callback(null, state);
}

// ---- The workflow: one handler per async boundary ------------------------------------
// Each handler: (1) checks the error FIRST and stops, (2) otherwise starts the
// next stage. `done` is the caller's final error-first callback.

function onStudentLoaded(error, state) {
  const { done } = state;
  if (error) { done(error); return; }
  checkPrerequisites(state, onPrerequisitesChecked);
}
function onPrerequisitesChecked(error, state) {
  const { done } = state;
  if (error) { done(error); return; }
  checkSeats(state, onSeatsChecked);
}
function onSeatsChecked(error, state) {
  const { done } = state;
  if (error) { done(error); return; }
  registerCourse(state, onCourseRegistered);
}
function onCourseRegistered(error, state) {
  const { done, confirmation } = state;
  if (error) { done(error); return; }
  done(null, confirmation);
}

// PUBLIC API
function registerForCourse(studentId, courseCode, done) {
  const state = { studentId, courseCode, done };
  loadStudent(state, onStudentLoaded);
}

// ---- Demo: scenarios are run one after another ------------------------------------------
const scenarios = [
  { studentId: 101, courseCode: 'CS401', expect: 'REGISTERED (takes the last seat)' },
  { studentId: 102, courseCode: 'CS401', expect: 'COURSE_FULL' },
  { studentId: 999, courseCode: 'CS401', expect: 'STUDENT_NOT_FOUND' },
  { studentId: 103, courseCode: 'CS401', expect: 'PREREQUISITE_MISSING' },
  { studentId: 101, courseCode: 'CS402', expect: 'REGISTERED' },
  { studentId: 101, courseCode: 'CS402', expect: 'ALREADY_REGISTERED' },
  { studentId: 101, courseCode: 'CS999', expect: 'COURSE_NOT_FOUND' },
];
let scenarioIndex = 0;

function runNextScenario() {
  if (scenarioIndex >= scenarios.length) {
    console.log('\nAll scenarios finished. Registrations stored:', database.registrations);
    printExplanation();
    return;
  }
  const { studentId, courseCode, expect } = scenarios[scenarioIndex];
  console.log(`\n#${scenarioIndex + 1} register student ${studentId} for ${courseCode}  (expected: ${expect})`);
  registerForCourse(studentId, courseCode, onScenarioDone);
}

function onScenarioDone(error, confirmation) {
  if (error) {
    console.log(`   FAILED  [${error.code ?? error.name}] ${error.message}`);
  } else {
    console.log('   SUCCESS', confirmation);
  }
  scenarioIndex += 1;
  runNextScenario();
}

function printExplanation() {
  console.log(`
=== Why callback workflows become hard to maintain ===
1. Nesting ("callback hell"): when each step depends on the previous one and the
   callbacks are written inline, every new stage is indented one level deeper:
       loadStudent(id, (e1, s) => { if (e1) ...
         checkPrereq(s, (e2, ok) => { if (e2) ...
           checkSeats(c, (e3, seats) => { if (e3) ...
             register(..., (e4, r) => { ... });
   Ten steps produce a "pyramid of doom" that is hard to read and to change.
   (Above we flattened it into named handlers, which helps, but the control
   flow is now spread over many small functions you must jump between.)
2. Repeated error handling: every single callback must start with
   "if (error) { ...; return; }". Forgetting one check or one return lets the
   workflow continue after a failure, or call the final callback twice.
3. No single place to catch errors: try/catch cannot catch an error thrown in
   a later tick, so each level needs its own handling and errors cannot just
   "bubble up" like in synchronous code.
4. Inversion of control: we hand our continuation to other code and trust it to
   call it exactly once - not zero times, not twice.
5. Adding, removing or re-ordering a stage means rewriting several functions,
   and running steps in parallel needs hand-written counters. Promises and
   async/await (Tasks 7 and 8) solve these problems.`);
}

console.log('=== TASK 6: callback-based registration ===');
runNextScenario();
