// =============================================================================
// Task 8 - Concurrent Academic API Aggregator with async/await
//
//   getJSON(url, fetchImplementation)   - safe JSON loader (ok check, errors)
//   fakeFetch(url, options)             - reproducible stand-in for fetch()
//   fetchWithTimeout(url, milliseconds) - AbortController + setTimeout + finally
//   loadDashboard()                     - three concurrent calls via Promise.all
//
// Needs Node 18+ (AbortController). No network access is used.
// =============================================================================

// ---- Error types: let callers tell the failure kinds apart -------------------------------
class HttpError extends Error {
  constructor(status, statusText, url) {
    super(`HTTP ${status} ${statusText} for ${url}`);
    this.name = 'HttpError';
    this.status = status;
    this.url = url;
  }
}
class NetworkError extends Error {
  constructor(url, options) {
    super(`Network failure while requesting ${url}`, options);
    this.name = 'NetworkError';
    this.url = url;
  }
}
class InvalidJsonError extends Error {
  constructor(url, options) {
    super(`Response from ${url} is not valid JSON`, options);
    this.name = 'InvalidJsonError';
    this.url = url;
  }
}
class TimeoutError extends Error {
  constructor(url, milliseconds) {
    super(`Request to ${url} timed out after ${milliseconds} ms`);
    this.name = 'TimeoutError';
    this.url = url;
  }
}

// =============================================================================
// FAKE FETCH (response-shaped objects, like the real Fetch API)
// =============================================================================
const USERS = [
  { id: 1, name: 'Ali', department: 'CS' },
  { id: 2, name: 'Sara', department: 'CS' },
  { id: 3, name: 'Usman', department: 'SE' },
  { id: 4, name: 'Hina', department: 'AI' },
  { id: 5, name: 'Ahmed', department: 'SE' },
  { id: 6, name: 'Zoya', department: 'AI' },
];
const COURSES = [
  { code: 'FSWD', title: 'Full Stack Web Development' },
  { code: 'DB', title: 'Databases' },
  { code: 'AI', title: 'Artificial Intelligence' },
];
const RESULTS = [
  { studentId: 1, courseCode: 'FSWD', marks: 82 }, { studentId: 1, courseCode: 'DB', marks: 78 },
  { studentId: 2, courseCode: 'FSWD', marks: 91 }, { studentId: 2, courseCode: 'DB', marks: 95 },
  { studentId: 3, courseCode: 'FSWD', marks: 47 }, { studentId: 3, courseCode: 'DB', marks: 41 },
  { studentId: 4, courseCode: 'FSWD', marks: 73 }, { studentId: 4, courseCode: 'AI', marks: 88 },
  { studentId: 5, courseCode: 'FSWD', marks: 64 }, { studentId: 5, courseCode: 'DB', marks: 52 },
  { studentId: 6, courseCode: 'FSWD', marks: 91 }, { studentId: 6, courseCode: 'AI', marks: 85 },
];

// url -> simulated server behaviour
const ROUTES = {
  '/users': { status: 200, body: JSON.stringify(USERS), delay: 200 },
  '/courses': { status: 200, body: JSON.stringify(COURSES), delay: 300 },
  '/results': { status: 200, body: JSON.stringify(RESULTS), delay: 250 },
  '/not-found': { status: 404, statusText: 'Not Found', body: '{"message":"missing"}', delay: 50 },
  '/server-error': { status: 500, statusText: 'Internal Server Error', body: '{"message":"boom"}', delay: 50 },
  '/network-failure': { networkFailure: true, delay: 50 },
  '/invalid-json': { status: 200, body: '{ "broken": [1, 2,', delay: 50 },
  '/slow': { status: 200, body: '{"slow":true}', delay: 3000 },
};

// Behaves like a fetch() Response: { ok, status, statusText, json() }.
class FakeResponse {
  constructor(status, statusText, body) {
    this.status = status;
    this.statusText = statusText;
    this.ok = status >= 200 && status <= 299;
    this.body = body;
  }
  async json() {
    return JSON.parse(this.body); // throws SyntaxError for invalid JSON, like the real one
  }
}

// Waits `ms`, but rejects immediately if the AbortSignal fires first.
function waitWithAbort(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(signal.reason);
      return;
    }
    const timerId = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    function onAbort() {
      clearTimeout(timerId); // no stray timer left behind
      reject(signal.reason);
    }
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

async function fakeFetch(url, { signal } = {}) {
  const route = ROUTES[url];
  if (!route) {
    await waitWithAbort(20, signal);
    return new FakeResponse(404, 'Not Found', '{"message":"unknown route"}');
  }
  await waitWithAbort(route.delay, signal);
  if (route.networkFailure) {
    throw new TypeError('fetch failed'); // exactly what real fetch throws for network errors
  }
  return new FakeResponse(route.status, route.statusText ?? 'OK', route.body);
}

// =============================================================================
// getJSON
// =============================================================================
// `options` is optional and only used to pass the AbortSignal through.
async function getJSON(url, fetchImplementation, options = {}) {
  let response;
  try {
    response = await fetchImplementation(url, options); // 1. call fetch
  } catch (error) {
    // Timeouts / manual aborts keep their identity; everything else is a network failure.
    if (error instanceof TimeoutError || error?.name === 'AbortError') throw error;
    throw new NetworkError(url, { cause: error });
  }

  if (!response.ok) {                                   // 2. check response.ok
    throw new HttpError(response.status, response.statusText, url); // 3. throw
  }

  try {
    return await response.json();                       // 4. parse and return
  } catch (error) {
    throw new InvalidJsonError(url, { cause: error });  // 5. propagate parse failure
  }
}

// =============================================================================
// fetchWithTimeout: AbortController + setTimeout + clearTimeout + try/finally
// =============================================================================
function abortWithTimeout(controller, url, milliseconds) {
  controller.abort(new TimeoutError(url, milliseconds)); // the abort *reason* identifies a timeout
}

async function fetchWithTimeout(url, milliseconds, fetchImplementation = fakeFetch) {
  const controller = new AbortController();
  const timerId = setTimeout(abortWithTimeout, milliseconds, controller, url, milliseconds);
  try {
    return await getJSON(url, fetchImplementation, { signal: controller.signal });
  } finally {
    clearTimeout(timerId); // runs for success, HTTP error, network error, bad JSON AND timeout
  }
}

// =============================================================================
// Dashboard
// =============================================================================
const DEFAULT_ENDPOINTS = { users: '/users', courses: '/courses', results: '/results' };
const PASS_MARKS = 50;
const round2 = (value) => Math.round(value * 100) / 100;

async function loadDashboard(timeoutMs = 2000, endpoints = DEFAULT_ENDPOINTS) {
  // All three requests START immediately (the promises are created first and
  // awaited together). Sequential `await`s would take 200 + 300 + 250 ms;
  // concurrently it takes only as long as the slowest one (~300 ms).
  //
  // Promise.all is the right combinator: the dashboard is useless without ALL
  // three data sets, so it should fail fast if any one of them fails.
  const [users, courses, results] = await Promise.all([
    fetchWithTimeout(endpoints.users, timeoutMs),
    fetchWithTimeout(endpoints.courses, timeoutMs),
    fetchWithTimeout(endpoints.results, timeoutMs),
  ]);
  return buildDashboard(users, courses, results);
}

function buildDashboard(users, courses, results) {
  if (![users, courses, results].every(Array.isArray)) {
    throw new TypeError('users, courses and results must all be arrays');
  }

  // Average per student (students without results are left out of averages).
  const students = users
    .map((user) => {
      const own = results.filter((result) => result.studentId === user.id);
      const average = own.length > 0 ? own.reduce((sum, r) => sum + r.marks, 0) / own.length : null;
      return { ...user, average: average === null ? null : round2(average) };
    })
    .filter((student) => student.average !== null);

  const allMarks = results.map((result) => result.marks);
  const overallAverage = allMarks.length > 0 ? round2(allMarks.reduce((sum, m) => sum + m, 0) / allMarks.length) : 0;

  const best = students.reduce((top, student) => (top === null || student.average > top.average ? student : top), null);

  // Failed student = overall average below pass marks.
  const failedStudents = students.filter((student) => student.average < PASS_MARKS);

  // Department statistics (works for any department that appears).
  const totals = students.reduce((acc, student) => {
    const current = acc[student.department] ?? { students: 0, total: 0, highest: -Infinity, failed: 0 };
    return {
      ...acc,
      [student.department]: {
        students: current.students + 1,
        total: current.total + student.average,
        highest: Math.max(current.highest, student.average),
        failed: current.failed + (student.average < PASS_MARKS ? 1 : 0),
      },
    };
  }, {});
  const departments = Object.fromEntries(
    Object.entries(totals).map(([name, d]) => [name, { students: d.students, average: round2(d.total / d.students), highest: d.highest, failed: d.failed }]),
  );

  return {
    totalStudents: users.length,
    totalCourses: courses.length,
    overallAverage,
    highestPerformingStudent: best ? { name: best.name, average: best.average } : null,
    failedStudents: failedStudents.length,
    departments,
  };
}

// =============================================================================
// DEMO
// =============================================================================
function countActiveTimers() {
  // Node >= 17.3: lists active resources. Proves no timeout timer is left.
  return typeof process.getActiveResourcesInfo === 'function'
    ? process.getActiveResourcesInfo().filter((name) => name === 'Timeout').length
    : 'n/a';
}

async function main() {
  console.log('=== 1. getJSON against every simulated situation ===');
  const cases = [
    ['200 success', '/courses'],
    ['404 response', '/not-found'],
    ['500 response', '/server-error'],
    ['network failure', '/network-failure'],
    ['invalid JSON', '/invalid-json'],
    ['unknown route', '/does-not-exist'],
  ];
  for (const [label, url] of cases) {
    try {
      const data = await getJSON(url, fakeFetch);
      console.log(`${label.padEnd(16)} -> OK, received ${Array.isArray(data) ? data.length + ' items' : JSON.stringify(data)}`);
    } catch (error) {
      console.log(`${label.padEnd(16)} -> ${error.name}: ${error.message}`);
    }
  }

  console.log('\n=== 2. fetchWithTimeout ===');
  const timeoutCases = [
    ['fast request, 1000 ms limit', '/users', 1000],
    ['slow request, 300 ms limit', '/slow', 300],
    ['404 inside timeout wrapper', '/not-found', 1000],
    ['network failure in wrapper', '/network-failure', 1000],
    ['invalid JSON in wrapper', '/invalid-json', 1000],
  ];
  for (const [label, url, limit] of timeoutCases) {
    try {
      const data = await fetchWithTimeout(url, limit);
      console.log(`${label.padEnd(30)} -> OK (${Array.isArray(data) ? data.length + ' items' : 'object'}) | active timers: ${countActiveTimers()}`);
    } catch (error) {
      const kind = error instanceof TimeoutError ? 'TIMEOUT/ABORT'
        : error instanceof HttpError ? 'HTTP FAILURE'
        : error instanceof NetworkError ? 'NETWORK FAILURE'
        : error instanceof InvalidJsonError ? 'INVALID JSON'
        : 'OTHER';
      console.log(`${label.padEnd(30)} -> ${kind}: ${error.message} | active timers: ${countActiveTimers()}`);
    }
  }

  console.log('\n=== 3. Concurrent dashboard (/users 200 ms, /courses 300 ms, /results 250 ms) ===');
  const startedAt = Date.now();
  const dashboard = await loadDashboard();
  const elapsed = Date.now() - startedAt;
  console.log(dashboard);
  console.log(`Loaded in ~${elapsed} ms (sequential awaits would need ~750 ms). Active timers afterwards: ${countActiveTimers()}`);

  console.log('\n=== 4. Dashboard when one service fails ===');
  try {
    await loadDashboard(2000, { users: '/users', courses: '/courses', results: '/server-error' });
  } catch (error) {
    console.log(`Dashboard failed fast -> ${error.name}: ${error.message}`);
  }

  console.log('\n=== 5. Dashboard when a service is too slow ===');
  const slowStart = Date.now();
  try {
    await loadDashboard(500, { users: '/users', courses: '/courses', results: '/slow' });
  } catch (error) {
    console.log(`Dashboard failed -> ${error.name}: ${error.message} (after ~${Date.now() - slowStart} ms)`);
  }

  console.log('\n=== 6. Edge case: empty data ===');
  console.log(buildDashboard([], [], []));
  try {
    buildDashboard(null, [], []);
  } catch (error) {
    console.log(`${error.name}: ${error.message}`);
  }
}

main().finally(() => {
  console.log(`\nDone. Timeout timers still active: ${countActiveTimers()}`);
});
