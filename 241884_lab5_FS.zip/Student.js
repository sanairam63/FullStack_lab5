// Student.js - the class is the DEFAULT export.
import { calculateAverage, calculateGPA, calculateGrade } from './gradeUtils.js';

export default class Student {
  constructor(id, name, courses = []) {
    this.id = id;
    this.name = name;
    this.courses = courses; // [{ code, marks }]
  }

  get marksList() {
    return this.courses.map((course) => course.marks);
  }

  get average() {
    return calculateAverage(this.marksList);
  }

  get gpa() {
    return calculateGPA(this.marksList);
  }

  // Plain, JSON-friendly representation used by the report.
  toReportEntry() {
    return {
      id: this.id,
      name: this.name,
      courses: this.courses.map(({ code, marks }) => ({ code, marks, ...calculateGrade(marks) })),
      average: this.average,
      gpa: this.gpa,
    };
  }
}
