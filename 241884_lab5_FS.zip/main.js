// main.js - the caller. Shows try / catch / finally plus all import styles.
//
// default import  : Student (no braces, any local name would work)
// named imports   : { ... } with the exact exported names
// aliased import  : calculateGrade as gradeOf
import Student from './Student.js';
import { calculateGrade as gradeOf, calculateAverage, calculateGPA } from './gradeUtils.js';
import { processTranscript, reportToJson } from './transcriptService.js';

const rawData = `
[
  {
    "id": 101,
    "name": "Ali",
    "courses": [
      { "code": "CS301", "marks": 81 },
      { "code": "CS302", "marks": 74 }
    ]
  },
  {
    "id": 102,
    "name": "Sara",
    "courses": [
      { "code": "CS301", "marks": 93 },
      { "code": "CS303", "marks": 48 }
    ]
  },
  { "id": 103, "name": "NewStudent", "courses": [] }
]`;

// Runs one scenario; always prints in `finally`.
function runScenario(title, jsonText) {
  console.log(`\n--- ${title} ---`);
  try {
    const report = processTranscript(jsonText);
    console.log(reportToJson(report));
    return true;
  } catch (error) {
    console.log(`REJECTED -> ${error.constructor.name}: ${error.message}`);
    return false;
  } finally {
    console.log(`(finally: "${title}" finished)`); // runs on success AND failure
  }
}

console.log('=== Direct use of the imports ===');
const demoStudent = new Student(1, 'Demo', [{ code: 'X1', marks: 90 }, { code: 'X2', marks: 65 }]);
console.log('gradeOf(81)                :', gradeOf(81));
console.log('calculateAverage([81, 74]) :', calculateAverage([81, 74]));
console.log('calculateGPA([81, 74])     :', calculateGPA([81, 74]));
console.log('Student average / gpa      :', demoStudent.average, '/', demoStudent.gpa);

runScenario('Valid data', rawData);

runScenario('Malformed JSON (missing bracket)', '[ { "id": 1, "name": "A", "courses": [ ');
runScenario('Not valid JSON at all', 'hello world');
runScenario('Not an array', '{"id": 1}');
runScenario('Missing student id', '[{ "name": "NoId", "courses": [] }]');
runScenario('Duplicate ids', '[{"id":1,"name":"A","courses":[]},{"id":1,"name":"B","courses":[]}]');
runScenario('Marks above 100', '[{"id":1,"name":"A","courses":[{"code":"CS1","marks":101}]}]');
runScenario('Marks below 0', '[{"id":1,"name":"A","courses":[{"code":"CS1","marks":-1}]}]');
runScenario('Marks are a string', '[{"id":1,"name":"A","courses":[{"code":"CS1","marks":"80"}]}]');
runScenario('Missing course code', '[{"id":1,"name":"A","courses":[{"marks":80}]}]');
runScenario('Boundary marks 0 and 100 (valid)', '[{"id":1,"name":"A","courses":[{"code":"CS1","marks":0},{"code":"CS2","marks":100}]}]');

console.log('\n--- Non-string input ---');
try {
  processTranscript(undefined);
} catch (error) {
  console.log(`${error.constructor.name}: ${error.message}`);
} finally {
  console.log('(finally: cleanup always runs)');
}
